package Aplicacao;
//Paulo Vieira Machado Neto
//Lucas Patrício de Aquino Silva
//Lucas Costa Souza
//Pedro Henrique Souza Moraes
//Paulo Gustavo Angelo de Barros
//Zeus Ramalho Costa Farias
public class ProgramaPrincipal {
    public static void main(String[] args) {
        ConverterMoeda conversor = new ConverterMoeda();
        conversor.converterMoeda();
    }
}