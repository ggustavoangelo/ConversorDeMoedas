package Aplicacao;

public interface ConversorInterface {
    public void inflacaoEUA();
    public void inflacaoReal();
    public void inflacaoLibra();
    public void inflacaoEuro();
    public void inflacaoFrancoSuico();
    public void inflacaoPesoArgentino();
    public void inflacaoDolarCanadense();
}